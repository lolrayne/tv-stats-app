module.exports = {
    SECRET_KEY: '0800898bb61d345ea6b7a9bea43d455dfed266b006607ed1585e51e78e50b3e9',
    SECRET_KEY_2: 'f6960a9'
}

